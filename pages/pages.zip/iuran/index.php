<?php
/**
 * Data Kategori Iuran
 * Sistem Administrasi Keuangan Sekolah
 */

// Start session and require config FIRST
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../../config/app.php';
require_once '../../config/database.php';

// Handle delete - BEFORE any HTML output
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);

    // Check if Iuran is used by students
    $check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM santri WHERE id_iuran = '$id'"));

    if ($check['total'] > 0) {
        setFlash('danger', 'Kategori Iuran tidak dapat dihapus karena digunakan oleh santri!');
    } else {
        if (mysqli_query($conn, "DELETE FROM iuran WHERE id_iuran = '$id'")) {
            logActivity('Menghapus kategori iuran', 'iuran', $id);
            setFlash('success', 'Kategori iuran berhasil dihapus!');
        } else {
            setFlash('danger', 'Gagal menghapus kategori iuran!');
        }
    }
    header("Location: index.php");
    exit;
}

// Handle add/edit - BEFORE any HTML output
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_iuran = isset($_POST['id_iuran']) ? sanitize($_POST['id_iuran']) : '';
    $nama_iuran = sanitize($_POST['nama_iuran']);
    $tahun = sanitize($_POST['tahun']);
    $periode_tipe = sanitize($_POST['periode_tipe'] ?? 'bulanan');
    $nominal = str_replace(['.', ','], '', $_POST['nominal']);
    $keterangan = sanitize($_POST['keterangan']);

    if (empty($nama_iuran) || empty($nominal)) {
        setFlash('danger', 'Nama iuran dan nominal harus diisi!');
    } else {
        if (empty($id_iuran)) {
            // Add new
            $query = "INSERT INTO iuran (nama_iuran, tahun, periode_tipe, nominal, keterangan) VALUES ('$nama_iuran', '$tahun', '$periode_tipe', '$nominal', '$keterangan')";
            $msg = 'ditambahkan';
        } else {
            // Edit
            $query = "UPDATE iuran SET nama_iuran = '$nama_iuran', tahun = '$tahun', periode_tipe = '$periode_tipe', nominal = '$nominal', keterangan = '$keterangan' WHERE id_iuran = '$id_iuran'";
            $msg = 'diubah';
        }

        if (mysqli_query($conn, $query)) {
            logActivity("Menyimpan kategori iuran ($msg)", 'iuran', $id_iuran ?: mysqli_insert_id($conn));
            setFlash('success', "Kategori iuran berhasil $msg!");
        } else {
            setFlash('danger', 'Gagal menyimpan kategori iuran!');
        }
    }
    header("Location: index.php");
    exit;
}

// NOW include header/sidebar - AFTER redirect logic
$page_title = 'Kategori Iuran';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

// Get data
$query = "SELECT b.*, COUNT(s.id_santri) as jumlah_santri 
          FROM iuran b 
          LEFT JOIN santri s ON b.id_iuran = s.id_iuran 
          GROUP BY b.id_iuran 
          ORDER BY b.nama_iuran ASC, b.tahun DESC";
$result = mysqli_query($conn, $query);
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-tags"></i></div>
                        Kategori Iuran
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#iuranModal"
                        onclick="resetForm()">
                        <i class="fas fa-plus me-1"></i> Tambah Kategori
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Kategori Iuran (Tagihan)</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Iuran</th>
                            <th>Tipe Periode</th>
                            <th>Tahun/Periode</th>
                            <th>Nominal</th>
                            <th>Keterangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td class="font-weight-bold"><?php echo htmlspecialchars($row['nama_iuran']); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo ($row['periode_tipe'] ?? 'bulanan') == 'tahunan' ? 'warning' : 'primary'; ?>">
                                        <?php echo ucfirst($row['periode_tipe'] ?? 'bulanan'); ?>
                                    </span>
                                </td>
                                <td><span class="badge bg-primary text-white"><?php echo $row['tahun']; ?></span></td>
                                <td class="font-weight-bold text-success"><?php echo formatRupiah($row['nominal']); ?></td>
                                <td><?php echo htmlspecialchars($row['keterangan']); ?></td>
                               
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                            <button class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle" id="dropdownMenuLink_<?php echo $row['id_iuran']; ?>" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink_<?php echo $row['id_iuran']; ?>">
                                                <div class="dropdown-header">Aksi:</div>
                                                <a class="dropdown-item" href="javascript:void(0)" onclick='editIuran(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, "UTF-8"); ?>)'>
                                                    <i class="fas fa-edit fa-sm fa-fw mr-2 text-gray-400"></i> Edit
                                                </a>
                                            </div>
                                        </div>
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark" onclick="confirmDelete('index.php?delete=<?php echo $row['id_iuran']; ?>')">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-xl -->

<!-- Modal -->
<div class="modal fade" id="iuranModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Kategori Iuran</h5>
                <button class="close" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="id_iuran" id="id_iuran">
                    <div class="form-group">
                        <label>Nama Iuran <span class="text-danger">*</span></label>
                        <input type="text" name="nama_iuran" id="nama_iuran" class="form-control" 
                            placeholder="Contoh: SPP Bulanan, Uang Seragam, dll" required>
                    </div>
                    <div class="form-group">
                        <label>Tahun/Periode</label>
                        <input type="number" name="tahun" id="tahun" class="form-control" min="2020" max="2050"
                            value="<?php echo date('Y'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Tipe Periode <span class="text-danger">*</span></label>
                        <select name="periode_tipe" id="periode_tipe" class="form-control" required>
                            <option value="bulanan">Bulanan</option>
                            <option value="tahunan">Tahunan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nominal <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                            </div>
                            <input type="text" name="nominal" id="nominal" class="form-control"
                                onkeyup="formatCurrency(this)" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Keterangan</label>
                        <textarea name="keterangan" id="keterangan" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = '
<script>
function resetForm() {
    document.getElementById("modalTitle").textContent = "Tambah Kategori Iuran";
    document.getElementById("id_iuran").value = "";
    document.getElementById("nama_iuran").value = "";
    document.getElementById("tahun").value = new Date().getFullYear();
    document.getElementById("periode_tipe").value = "bulanan";
    document.getElementById("nominal").value = "";
    document.getElementById("keterangan").value = "";
}

function editIuran(data) {
    document.getElementById("modalTitle").textContent = "Edit Kategori Iuran";
    document.getElementById("id_iuran").value = data.id_iuran;
    document.getElementById("nama_iuran").value = data.nama_iuran;
    document.getElementById("tahun").value = data.tahun;
    document.getElementById("periode_tipe").value = data.periode_tipe || "bulanan";
    document.getElementById("nominal").value = new Intl.NumberFormat("id-ID").format(data.nominal);
    document.getElementById("keterangan").value = data.keterangan || "";
    $("#iuranModal").modal("show");
}
</script>
';

require_once '../../includes/footer.php';
?>



