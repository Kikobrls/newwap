<?php
/**
 * Export Jurnal Umum ke Excel (.xlsx asli via PhpSpreadsheet)
 * Sistem Administrasi Keuangan Sekolah
 */

session_start();
require_once '../../config/app.php';
require_once '../../config/database.php';
require_once '../../vendor/autoload.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../../login.php");
    exit;
}

// Settings untuk kop
$nama_sekolah   = getSetting('nama_sekolah', 'TPQ Keuangan');
$alamat_sekolah = getSetting('alamat_sekolah', '');

// Filter (sama seperti index.php)
$filter_pos    = isset($_GET['filter_pos']) ? sanitize($_GET['filter_pos']) : '';
$filter_dari   = isset($_GET['dari'])    ? sanitize($_GET['dari'])    : '';
$filter_sampai = isset($_GET['sampai'])  ? sanitize($_GET['sampai'])  : '';
$filter_jenis  = isset($_GET['jenis'])   ? sanitize($_GET['jenis'])   : '';

$where_parts = [];
if (!empty($filter_pos))    $where_parts[] = "j.id_pos = '$filter_pos'";
if (!empty($filter_dari))   $where_parts[] = "j.tanggal >= '$filter_dari'";
if (!empty($filter_sampai)) $where_parts[] = "j.tanggal <= '$filter_sampai'";
if (!empty($filter_jenis))  $where_parts[] = "j.jenis = '$filter_jenis'";
$where = !empty($where_parts) ? 'WHERE ' . implode(' AND ', $where_parts) : '';

$query = "SELECT j.*, p.nama_pos
          FROM jurnal_umum j
          JOIN pos_keuangan p ON j.id_pos = p.id_pos
          $where
          ORDER BY j.tanggal DESC, j.id_jurnal DESC";
$result = mysqli_query($conn, $query);

$total_masuk  = 0;
$total_keluar = 0;

$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Jurnal Umum');

// Kop / Judul
$sheet->mergeCells('A1:F1');
$sheet->setCellValue('A1', strtoupper($nama_sekolah));
$sheet->mergeCells('A2:F2');
$sheet->setCellValue('A2', 'DATA JURNAL UMUM');

$titleStyle = [
    'font' => ['bold' => true, 'size' => 12],
    'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
];
$sheet->getStyle('A1')->applyFromArray($titleStyle);
$sheet->getStyle('A2')->applyFromArray($titleStyle);

$rowNum = 4;
if (!empty($alamat_sekolah)) {
    $sheet->mergeCells('A3:F3');
    $sheet->setCellValue('A3', $alamat_sekolah);
    $sheet->getStyle('A3')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    $rowNum = 5;
}

// Header tabel
$headers = ['No', 'Tanggal', 'Pos Keuangan', 'Uraian', 'Jenis', 'Nominal'];
$col = 'A';
foreach ($headers as $h) {
    $sheet->setCellValue($col . $rowNum, $h);
    $col++;
}
$headerRange = 'A' . $rowNum . ':F' . $rowNum;
$sheet->getStyle($headerRange)->applyFromArray([
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '4E73DF']],
    'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
    'borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN]],
]);

// Data
$dataStart = $rowNum + 1;
$r = $dataStart;
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    $nominal = (float)$row['nominal'];
    if ($row['jenis'] == 'Pemasukan') {
        $total_masuk += $nominal;
    } else {
        $total_keluar += $nominal;
    }

    $sheet->setCellValue('A' . $r, $no++);
    $sheet->setCellValueExplicit('B' . $r, date('d/m/Y', strtotime($row['tanggal'])), \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING);
    $sheet->setCellValue('C' . $r, $row['nama_pos']);
    $sheet->setCellValue('D' . $r, $row['uraian']);
    $sheet->setCellValue('E' . $r, $row['jenis']);
    $sheet->setCellValue('F' . $r, $nominal);
    $sheet->getStyle('A' . $r)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
    $r++;
}

$dataEnd = $r - 1;

// Baris total
$saldo_akhir = $total_masuk - $total_keluar;

$sheet->mergeCells('A' . $r . ':E' . $r);
$sheet->setCellValue('A' . $r, 'Total Pemasukan');
$sheet->setCellValue('F' . $r, $total_masuk);
$rMasuk = $r;
$r++;

$sheet->mergeCells('A' . $r . ':E' . $r);
$sheet->setCellValue('A' . $r, 'Total Pengeluaran');
$sheet->setCellValue('F' . $r, $total_keluar);
$rKeluar = $r;
$r++;

$sheet->mergeCells('A' . $r . ':E' . $r);
$sheet->setCellValue('A' . $r, 'Saldo Akhir');
$sheet->setCellValue('F' . $r, $saldo_akhir);
$rSaldo = $r;

$sheet->getStyle('A' . $rMasuk . ':F' . $rSaldo)->applyFromArray([
    'font' => ['bold' => true],
    'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F2F2F2']],
    'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_RIGHT],
]);

// Border seluruh tabel + format angka
$tableRange = 'A' . $rowNum . ':F' . $rSaldo;
$sheet->getStyle($tableRange)->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
if ($dataEnd >= $dataStart) {
    $sheet->getStyle('F' . $dataStart . ':F' . $dataEnd)->getNumberFormat()->setFormatCode('#,##0');
}
$sheet->getStyle('F' . $rMasuk . ':F' . $rSaldo)->getNumberFormat()->setFormatCode('#,##0');

// Lebar kolom
$sheet->getColumnDimension('A')->setWidth(6);
$sheet->getColumnDimension('B')->setWidth(14);
$sheet->getColumnDimension('C')->setWidth(24);
$sheet->getColumnDimension('D')->setWidth(40);
$sheet->getColumnDimension('E')->setWidth(14);
$sheet->getColumnDimension('F')->setWidth(18);

$filename = 'Jurnal_Umum_' . date('Y-m-d') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
$writer->save('php://output');
exit;
