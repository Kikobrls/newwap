<?php
/**
 * Halaman Data Jurnal Umum
 * Sistem Keuangan TPQ
 *
 * Satu file menangani 4 aksi:
 *   1. HAPUS  : GET  ?delete=<id_jurnal>            -> redirect index.php
 *   2. TAMBAH : POST action=add                     -> redirect index.php
 *   3. EDIT   : POST action=edit (wajib id_jurnal)  -> redirect index.php
 *   4. TAMPIL : GET biasa, daftar jurnal + saldo akhir dengan
 *               filter opsional (filter_pos, jenis, dari, sampai)
 *
 * Aksi 1-3 dijalankan SEBELUM output HTML agar header() redirect valid.
 */

// Start session dan config terlebih dahulu
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../../config/app.php';
require_once '../../config/database.php';

/* =========================================================
 * AKSI 1: HAPUS DATA (GET ?delete=<id_jurnal>)
 * ========================================================= */
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);

    if (mysqli_query($conn, "DELETE FROM jurnal_umum WHERE id_jurnal = '$id'")) {
        logActivity('Menghapus data Jurnal Umum', 'jurnal_umum', $id);
        setFlash('success', 'Data Jurnal Umum berhasil dihapus!');
    } else {
        setFlash('danger', 'Gagal menghapus data Jurnal Umum!');
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 2: TAMBAH DATA (POST action=add)
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'add') {
    // Ambil input form (nominal: buang pemisah ribuan "." dan ",")
    $tanggal = sanitize($_POST['tanggal']);
    $id_pos  = sanitize($_POST['id_pos']);
    $uraian  = sanitize($_POST['uraian']);
    $jenis   = sanitize($_POST['jenis']);
    $nominal = str_replace(['.', ','], '', $_POST['nominal']);

    // Validasi: semua field wajib diisi
    if (empty($tanggal) || empty($id_pos) || empty($uraian) || empty($jenis) || empty($nominal)) {
        setFlash('danger', 'Semua form dengan tanda * wajib diisi!');
    } elseif (mysqli_query($conn, "INSERT INTO jurnal_umum (tanggal, id_pos, uraian, jenis, nominal)
                                   VALUES ('$tanggal', '$id_pos', '$uraian', '$jenis', '$nominal')")) {
        logActivity('Menambah data Jurnal Umum', 'jurnal_umum', mysqli_insert_id($conn));
        setFlash('success', 'Data Jurnal Umum berhasil ditambahkan!');
    } else {
        setFlash('danger', 'Gagal menambah data Jurnal Umum!');
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 3: EDIT DATA (POST action=edit)
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'edit') {
    // Ambil input form (nominal: buang pemisah ribuan "." dan ",")
    $id_jurnal = sanitize($_POST['id_jurnal'] ?? '');
    $tanggal = sanitize($_POST['tanggal']);
    $id_pos  = sanitize($_POST['id_pos']);
    $uraian  = sanitize($_POST['uraian']);
    $jenis   = sanitize($_POST['jenis']);
    $nominal = str_replace(['.', ','], '', $_POST['nominal']);

    // Validasi: id_jurnal dan semua field wajib diisi
    if (empty($id_jurnal) || empty($tanggal) || empty($id_pos) || empty($uraian) || empty($jenis) || empty($nominal)) {
        setFlash('danger', 'Semua form dengan tanda * wajib diisi!');
    } elseif (mysqli_query($conn, "UPDATE jurnal_umum
                                   SET tanggal = '$tanggal', id_pos = '$id_pos', uraian = '$uraian',
                                       jenis = '$jenis', nominal = '$nominal'
                                   WHERE id_jurnal = '$id_jurnal'")) {
        logActivity('Mengubah data Jurnal Umum', 'jurnal_umum', $id_jurnal);
        setFlash('success', 'Data Jurnal Umum berhasil diubah!');
    } else {
        setFlash('danger', 'Gagal mengubah data Jurnal Umum!');
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 4: TAMPILKAN HALAMAN (daftar jurnal + saldo + filter)
 * ========================================================= */

// Include layout SETELAH logika redirect di atas
$page_title = 'Data Jurnal Umum';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

// --- Baca parameter filter (GET) ---
$filter_pos    = isset($_GET['filter_pos']) ? sanitize($_GET['filter_pos']) : '';
$filter_dari   = isset($_GET['dari'])    ? sanitize($_GET['dari'])    : '';
$filter_sampai = isset($_GET['sampai'])  ? sanitize($_GET['sampai'])  : '';
$filter_jenis  = isset($_GET['jenis'])   ? sanitize($_GET['jenis'])   : '';
$has_filter    = $filter_pos !== '' || $filter_dari !== '' || $filter_sampai !== '' || $filter_jenis !== '';

// --- Susun klausa WHERE sesuai filter aktif ---
$where_parts = [];
if (!empty($filter_pos))    $where_parts[] = "j.id_pos = '$filter_pos'";
if (!empty($filter_dari))   $where_parts[] = "j.tanggal >= '$filter_dari'";
if (!empty($filter_sampai)) $where_parts[] = "j.tanggal <= '$filter_sampai'";
if (!empty($filter_jenis))  $where_parts[] = "j.jenis = '$filter_jenis'";
$where = !empty($where_parts) ? 'WHERE ' . implode(' AND ', $where_parts) : '';

// --- Query daftar transaksi jurnal ---
$query = "SELECT j.*, p.nama_pos
          FROM jurnal_umum j
          JOIN pos_keuangan p ON j.id_pos = p.id_pos
          $where
          ORDER BY j.tanggal DESC, j.id_jurnal DESC";
$result = mysqli_query($conn, $query);

// --- Hitung total pemasukan, pengeluaran, dan saldo akhir ---
$query_saldo = "SELECT
                SUM(CASE WHEN jenis = 'Pemasukan' THEN nominal ELSE 0 END) as total_masuk,
                SUM(CASE WHEN jenis = 'Pengeluaran' THEN nominal ELSE 0 END) as total_keluar
                FROM jurnal_umum j
                $where";
$res_saldo = mysqli_query($conn, $query_saldo);
$saldo_data = mysqli_fetch_assoc($res_saldo);
$total_masuk  = $saldo_data['total_masuk']  ?? 0;
$total_keluar = $saldo_data['total_keluar'] ?? 0;
$saldo_akhir  = $total_masuk - $total_keluar;

// --- URL export (bawa filter aktif ke halaman export) ---
$export_params = http_build_query(array_filter([
    'filter_pos' => $filter_pos,
    'dari'       => $filter_dari,
    'sampai'     => $filter_sampai,
    'jenis'      => $filter_jenis,
]));
$export_url = 'export.php' . ($export_params ? '?' . $export_params : '');

// --- Daftar pos keuangan untuk dropdown filter & form modal ---
$query_pos = "SELECT * FROM pos_keuangan ORDER BY nama_pos ASC";
$result_pos = mysqli_query($conn, $query_pos);
$list_pos = [];
while ($row = mysqli_fetch_assoc($result_pos)) {
    $list_pos[] = $row;
}
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-book"></i></div>
                        Data Jurnal Umum
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <button class="btn btn-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFilter" aria-expanded="false" aria-controls="collapseFilter">
                        <i class="fas fa-filter me-1"></i> Filter
                    </button>
                    <!-- Export Excel (.xlsx via PhpSpreadsheet) -->
                    <a class="btn btn-success" href="<?php echo $export_url; ?>">
                        <i class="fas fa-file-excel me-1"></i> Export Excel
                    </a>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#jurnalModal"
                        onclick="resetForm()">
                        <i class="fas fa-plus me-1"></i> Tambah Jurnal
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <!-- Filter Card (otomatis terbuka jika ada filter aktif) -->
    <div class="collapse mb-4 <?php echo $has_filter ? 'show' : ''; ?>" id="collapseFilter">
        <div class="card shadow">
            <div class="card-header py-2">
                <h6 class="m-0 font-weight-bold text-secondary"><i class="fas fa-sliders-h mr-1"></i> Filter Data</h6>
            </div>
            <div class="card-body">
                <form method="GET" action="" id="filterForm">
                    <div class="row align-items-end">
                        <div class="col-md-3 mb-2">
                            <label class="small font-weight-bold text-gray-600">Pos Keuangan</label>
                            <select name="filter_pos" id="filter_pos" class="form-control form-control-sm">
                                <option value="">-- Semua Pos --</option>
                                <?php foreach ($list_pos as $pos): ?>
                                    <option value="<?php echo $pos['id_pos']; ?>" <?php echo $filter_pos == $pos['id_pos'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($pos['nama_pos']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="small font-weight-bold text-gray-600">Jenis</label>
                            <select name="jenis" id="filter_jenis" class="form-control form-control-sm">
                                <option value="">-- Semua --</option>
                                <option value="Pemasukan"  <?php echo $filter_jenis=='Pemasukan'   ? 'selected' : ''; ?>>Pemasukan</option>
                                <option value="Pengeluaran" <?php echo $filter_jenis=='Pengeluaran' ? 'selected' : ''; ?>>Pengeluaran</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="small font-weight-bold text-gray-600">Dari Tanggal</label>
                            <input type="date" name="dari" id="filter_dari" class="form-control form-control-sm" value="<?php echo $filter_dari; ?>">
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="small font-weight-bold text-gray-600">Sampai Tanggal</label>
                            <input type="date" name="sampai" id="filter_sampai" class="form-control form-control-sm" value="<?php echo $filter_sampai; ?>">
                        </div>
                        <div class="col-md-3 mb-2">
                            <button type="submit" class="btn btn-primary btn-sm mr-1">
                                <i class="fas fa-filter fa-sm"></i> Filter
                            </button>
                            <?php if ($has_filter): ?>
                                <a href="index.php" class="btn btn-secondary btn-sm">
                                    <i class="fas fa-sync fa-sm"></i> Reset
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Ringkasan Keuangan (Cards) -->
    <div class="row">

        <!-- Total Pemasukan -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                TOTAL PEMASUKAN</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo formatRupiah($total_masuk); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-down fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Total Pengeluaran -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                TOTAL PENGELUARAN</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo formatRupiah($total_keluar); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-arrow-up fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Saldo Akhir -->
        <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-<?php echo $saldo_akhir >= 0 ? 'primary' : 'danger'; ?> shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-<?php echo $saldo_akhir >= 0 ? 'primary' : 'danger'; ?> text-uppercase mb-1">
                                SALDO AKHIR</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo formatRupiah($saldo_akhir); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-wallet fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Transaksi Jurnal</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th>Tanggal</th>
                            <th>Pos Keuangan</th>
                            <th>Uraian</th>
                            <th>Jenis</th>
                            <th>Nominal</th>
                            <th width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tanggal'])); ?></td>
                                <td><?php echo htmlspecialchars($row['nama_pos']); ?></td>
                                <td><?php echo htmlspecialchars($row['uraian']); ?></td>
                                <td>
                                    <?php if ($row['jenis'] == 'Pemasukan'): ?>
                                        <span class="badge bg-success text-white"><i class="fas fa-arrow-down mr-1"></i>Pemasukan</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger text-white"><i class="fas fa-arrow-up mr-1"></i>Pengeluaran</span>
                                    <?php endif; ?>
                                </td>
                                <td class="font-weight-bold text-right">
                                    <?php
                                    if ($row['jenis'] == 'Pemasukan') {
                                        echo '<span class="text-success">' . formatRupiah($row['nominal']) . '</span>';
                                    } else {
                                        echo '<span class="text-danger">-' . formatRupiah($row['nominal']) . '</span>';
                                    }
                                    ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                            <button class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle" id="dropdownMenuLink_<?php echo $row['id_jurnal']; ?>" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink_<?php echo $row['id_jurnal']; ?>">
                                                <div class="dropdown-header">Aksi:</div>
                                                <a class="dropdown-item" href="javascript:void(0)" onclick='editJurnal(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, "UTF-8"); ?>)'>
                                                    <i class="fas fa-edit fa-sm fa-fw mr-2 text-gray-400"></i> Edit
                                                </a>
                                            </div>
                                        </div>
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark" onclick="confirmDelete('index.php?delete=<?php echo $row['id_jurnal']; ?>')">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-xl -->

<!-- Modal -->
<div class="modal fade" id="jurnalModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Jurnal Umum</h5>
                <button class="close" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" id="form_action" value="add">
                    <input type="hidden" name="id_jurnal" id="id_jurnal">

                    <div class="form-group">
                        <label>Tanggal <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Pos Keuangan <span class="text-danger">*</span></label>
                        <select name="id_pos" id="id_pos" class="form-control" required>
                            <option value="">-- Pilih Pos Keuangan --</option>
                            <?php foreach ($list_pos as $pos): ?>
                                <option value="<?php echo $pos['id_pos']; ?>"><?php echo htmlspecialchars($pos['nama_pos']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Uraian Transaksi <span class="text-danger">*</span></label>
                        <textarea name="uraian" id="uraian" class="form-control" rows="2" placeholder="Contoh: Pembayaran listrik bulan Maret..." required></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jenis <span class="text-danger">*</span></label>
                                <select name="jenis" id="jenis" class="form-control" required>
                                    <option value="Pemasukan">Pemasukan</option>
                                    <option value="Pengeluaran">Pengeluaran</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nominal <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">Rp</span>
                                    </div>
                                    <input type="text" name="nominal" id="nominal" class="form-control"
                                        onkeyup="formatCurrency(this)" required>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = '
<script>
function resetForm() {
    document.getElementById("modalTitle").textContent = "Tambah Jurnal Umum";
    document.getElementById("form_action").value = "add";
    document.getElementById("id_jurnal").value = "";
    document.getElementById("tanggal").value = "' . date('Y-m-d') . '";
    document.getElementById("id_pos").value = "";
    document.getElementById("uraian").value = "";
    document.getElementById("jenis").value = "Pemasukan";
    document.getElementById("nominal").value = "";
}

function editJurnal(data) {
    document.getElementById("modalTitle").textContent = "Edit Jurnal Umum";
    document.getElementById("form_action").value = "edit";
    document.getElementById("id_jurnal").value = data.id_jurnal;
    document.getElementById("tanggal").value = data.tanggal;
    document.getElementById("id_pos").value = data.id_pos;
    document.getElementById("uraian").value = data.uraian;
    document.getElementById("jenis").value = data.jenis;
    document.getElementById("nominal").value = new Intl.NumberFormat("id-ID").format(data.nominal);
    $("#jurnalModal").modal("show");
}
</script>
';

require_once '../../includes/footer.php';
?>
