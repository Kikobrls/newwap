<?php
/**
 * Data Kelas
 * Sistem Keuangan TPQ
 */

// Start session and require config FIRST
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../../config/app.php';
require_once '../../config/database.php';

// Handle delete - BEFORE any HTML output
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);

    // Check if class has students
    $check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM santri WHERE id_kelas = '$id'"));

    if ($check['total'] > 0) {
        setFlash('danger', 'Kelas tidak dapat dihapus karena memiliki data santri!');
    } else {
        if (mysqli_query($conn, "DELETE FROM kelas WHERE id_kelas = '$id'")) {
            logActivity('Menghapus data kelas', 'kelas', $id);
            setFlash('success', 'Data kelas berhasil dihapus!');
        } else {
            setFlash('danger', 'Gagal menghapus data kelas!');
        }
    }
    header("Location: index.php");
    exit;
}

// Handle add/edit - BEFORE any HTML output
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_kelas = isset($_POST['id_kelas']) ? sanitize($_POST['id_kelas']) : '';
    $nama_kelas = sanitize($_POST['nama_kelas']);

    if (empty($nama_kelas)) {
        setFlash('danger', 'Nama kelas harus diisi!');
    } else {
        if (empty($id_kelas)) {
            // Add new
            $query = "INSERT INTO kelas (nama_kelas) VALUES ('$nama_kelas')";
            $msg = 'ditambahkan';
        } else {
            // Edit
            $query = "UPDATE kelas SET nama_kelas = '$nama_kelas' WHERE id_kelas = '$id_kelas'";
            $msg = 'diubah';
        }

        if (mysqli_query($conn, $query)) {
            logActivity("Menyimpan data kelas ($msg)", 'kelas', $id_kelas ?: mysqli_insert_id($conn));
            setFlash('success', "Data kelas berhasil $msg!");
        } else {
            setFlash('danger', 'Gagal menyimpan data kelas!');
        }
    }
    header("Location: index.php");
    exit;
}

// NOW include header/sidebar - AFTER redirect logic
$page_title = 'Data Kelas';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

// Get data
$query = "SELECT k.*, COUNT(s.id_santri) as jumlah_santri
          FROM kelas k
          LEFT JOIN santri s ON k.id_kelas = s.id_kelas
          GROUP BY k.id_kelas
          ORDER BY k.nama_kelas";
$result = mysqli_query($conn, $query);
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-chalkboard"></i></div>
                        Data Kelas
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <a href="<?php echo $base_url; ?>/pages/santri/pindahkelas.php" class="btn btn-outline-primary me-2">
                        <i class="fas fa-exchange-alt me-1"></i> Pindah Kelas Santri
                    </a>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kelasModal"
                        onclick="resetForm()">
                        <i class="fas fa-plus me-1"></i> Tambah Kelas
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">



    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Kelas</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kelas</th>
                            <th>Jumlah Santri</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                                <td class="text-center">
                                    <span class="badge bg-info text-dark"><?php echo $row['jumlah_santri']; ?></span>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                            <button class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle" id="dropdownMenuLink_<?php echo $row['id_kelas']; ?>" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink_<?php echo $row['id_kelas']; ?>">
                                                <div class="dropdown-header">Aksi:</div>
                                                <a class="dropdown-item" href="javascript:void(0)" onclick='editKelas(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, "UTF-8"); ?>)'>
                                                    <i class="fas fa-edit fa-sm fa-fw mr-2 text-gray-400"></i> Edit
                                                </a>
                                            </div>
                                        </div>
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark" onclick="confirmDelete('index.php?delete=<?php echo $row['id_kelas']; ?>')">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-xl -->

<!-- Modal -->
<div class="modal fade" id="kelasModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Kelas</h5>
                <button class="close" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="id_kelas" id="id_kelas">
                    <div class="form-group">
                        <label>Nama Kelas <span class="text-danger">*</span></label>
                        <input type="text" name="nama_kelas" id="nama_kelas" class="form-control" required>
                        <small class="text-muted">Contoh: X RPL 1, XI TKJ 2</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = '
<script>
function resetForm() {
    document.getElementById("modalTitle").textContent = "Tambah Kelas";
    document.getElementById("id_kelas").value = "";
    document.getElementById("nama_kelas").value = "";
}

function editKelas(data) {
    document.getElementById("modalTitle").textContent = "Edit Kelas";
    document.getElementById("id_kelas").value = data.id_kelas;
    document.getElementById("nama_kelas").value = data.nama_kelas;
    $("#kelasModal").modal("show");
}
</script>
';

require_once '../../includes/footer.php';
?>
