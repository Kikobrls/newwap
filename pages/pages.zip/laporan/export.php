<?php
/**
 * Export Laporan Pembayaran, Jurnal, dan Kas
 * Sistem Administrasi Keuangan Sekolah
 */

session_start();
require_once '../../config/database.php';
require_once '../../config/app.php';

if (!isset($_SESSION['login'])) {
    header("Location: ../../login.php");
    exit;
}

// Get Settings for Header (Kop Surat)
$nama_sekolah = getSetting('nama_sekolah', 'TPQ Keuangan');
$alamat_sekolah = getSetting('alamat_sekolah', '');
$telp_sekolah = getSetting('telp_sekolah', '');
$email_sekolah = getSetting('email_sekolah', '');
$website_sekolah = getSetting('website_sekolah', '');

// Filters
$filter_tahun = isset($_GET['tahun']) ? sanitize($_GET['tahun']) : date('Y');

$bulan_list = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'Desember'
];

// Perform 12-month aggregation query
$report_data = [];
$total_pemasukan_year = 0;
$total_pengeluaran_year = 0;
$total_sisa_kas_year = 0;

for ($m = 1; $m <= 12; $m++) {
    $bulan_str = str_pad($m, 2, '0', STR_PAD_LEFT);

    // Pemasukan (dari jurnal_umum)
    $q_jurnal_in = mysqli_query($conn, "SELECT SUM(nominal) as total FROM jurnal_umum WHERE jenis = 'Pemasukan' AND MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$filter_tahun'");
    $r_jurnal_in = mysqli_fetch_assoc($q_jurnal_in);
    $total_in = (float)($r_jurnal_in['total'] ?? 0);

    // Pengeluaran (dari jurnal_umum)
    $q_jurnal_out = mysqli_query($conn, "SELECT SUM(nominal) as total FROM jurnal_umum WHERE jenis = 'Pengeluaran' AND MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$filter_tahun'");
    $r_jurnal_out = mysqli_fetch_assoc($q_jurnal_out);
    $jurnal_out = (float)($r_jurnal_out['total'] ?? 0);

    $sisa_kas = $total_in - $jurnal_out;

    $report_data[$m] = [
        'bulan' => $bulan_list[$bulan_str],
        'total_in' => $total_in,
        'jurnal_out' => $jurnal_out,
        'sisa_kas' => $sisa_kas
    ];

    $total_pemasukan_year += $total_in;
    $total_pengeluaran_year += $jurnal_out;
    $total_sisa_kas_year += $sisa_kas;
}

$type = isset($_GET['type']) ? $_GET['type'] : 'print';

// Handle Export to Excel (.xlsx asli via PhpSpreadsheet)
if ($type == 'excel') {
    require_once '../../vendor/autoload.php';

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Laporan ' . $filter_tahun);

    // Kop / Judul
    $sheet->mergeCells('A1:E1');
    $sheet->setCellValue('A1', strtoupper($nama_sekolah));
    $sheet->mergeCells('A2:E2');
    $sheet->setCellValue('A2', 'LAPORAN REKAPITULASI KEUANGAN BULANAN');
    $sheet->mergeCells('A3:E3');
    $sheet->setCellValue('A3', 'Tahun Keuangan: ' . $filter_tahun);

    $titleStyle = [
        'font' => ['bold' => true, 'size' => 12],
        'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
    ];
    $sheet->getStyle('A1')->applyFromArray($titleStyle);
    $sheet->getStyle('A2')->applyFromArray($titleStyle);
    $sheet->getStyle('A3:E3')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    $rowNum = 5;
    if (!empty($alamat_sekolah)) {
        $sheet->mergeCells('A4:E4');
        $sheet->setCellValue('A4', $alamat_sekolah);
        $sheet->getStyle('A4')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
        $rowNum = 6;
    }

    // Header tabel
    $headers = ['No', 'Bulan', 'Total Pemasukan', 'Total Pengeluaran', 'Sisa Kas'];
    $col = 'A';
    foreach ($headers as $h) {
        $sheet->setCellValue($col . $rowNum, $h);
        $col++;
    }
    $headerRange = 'A' . $rowNum . ':E' . $rowNum;
    $sheet->getStyle($headerRange)->applyFromArray([
        'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
        'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => '4E73DF']],
        'alignment' => ['horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER],
        'borders' => ['allBorders' => ['borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN]],
    ]);

    // Data
    $dataStart = $rowNum + 1;
    $r = $dataStart;
    foreach ($report_data as $m => $row) {
        $sheet->setCellValue('A' . $r, $m);
        $sheet->setCellValue('B' . $r, $row['bulan']);
        $sheet->setCellValue('C' . $r, $row['total_in']);
        $sheet->setCellValue('D' . $r, $row['jurnal_out']);
        $sheet->setCellValue('E' . $r, $row['sisa_kas']);
        $sheet->getStyle('A' . $r)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
        $r++;
    }

    // Total
    $sheet->mergeCells('A' . $r . ':B' . $r);
    $sheet->setCellValue('A' . $r, 'TOTAL TAHUNAN');
    $sheet->setCellValue('C' . $r, $total_pemasukan_year);
    $sheet->setCellValue('D' . $r, $total_pengeluaran_year);
    $sheet->setCellValue('E' . $r, $total_sisa_kas_year);
    $sheet->getStyle('A' . $r . ':E' . $r)->applyFromArray([
        'font' => ['bold' => true],
        'fill' => ['fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID, 'startColor' => ['rgb' => 'F2F2F2']],
    ]);
    $sheet->getStyle('A' . $r)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);

    // Border seluruh tabel + format angka rupiah
    $tableRange = 'A' . $rowNum . ':E' . $r;
    $sheet->getStyle($tableRange)->getBorders()->getAllBorders()->setBorderStyle(\PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN);
    $sheet->getStyle('C' . $dataStart . ':E' . $r)->getNumberFormat()->setFormatCode('#,##0');

    // Lebar kolom
    $sheet->getColumnDimension('A')->setWidth(6);
    $sheet->getColumnDimension('B')->setWidth(16);
    $sheet->getColumnDimension('C')->setWidth(20);
    $sheet->getColumnDimension('D')->setWidth(20);
    $sheet->getColumnDimension('E')->setWidth(20);

    $filename = 'laporan_keuangan_bulanan_' . $filter_tahun . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}

// Handle Export to PDF via Dompdf
if ($type == 'pdf') {
    require_once '../../vendor/autoload.php';
    
    $options = new \Dompdf\Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isRemoteEnabled', false);
    $options->set('defaultFont', 'Helvetica');
    
    $dompdf = new \Dompdf\Dompdf($options);

    ob_start();
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Laporan Keuangan Bulanan <?php echo $filter_tahun; ?></title>
        <style>
            body {
                font-family: Helvetica, Arial, sans-serif;
                font-size: 10px;
                color: #222;
                line-height: 1.3;
            }
            .kop-table {
                width: 100%;
                border-collapse: collapse;
                border-bottom: 3px double #000000;
                padding-bottom: 8px;
                margin-bottom: 15px;
            }
            .kop-logo {
                width: 60px;
                text-align: center;
                vertical-align: middle;
            }
            .kop-logo-placeholder {
                border: 2px solid #000;
                border-radius: 50%;
                width: 45px;
                height: 45px;
                line-height: 45px;
                font-size: 20px;
                font-weight: bold;
                text-align: center;
            }
            .kop-details {
                text-align: center;
                vertical-align: middle;
            }
            .kop-details h1 {
                font-size: 16px;
                margin: 0;
                font-weight: bold;
                text-transform: uppercase;
            }
            .kop-details p {
                font-size: 9px;
                margin: 2px 0 0 0;
                color: #444;
            }
            .report-title {
                text-align: center;
                margin-bottom: 15px;
            }
            .report-title h2 {
                font-size: 13px;
                margin: 0 0 3px 0;
                font-weight: bold;
                text-transform: uppercase;
            }
            .report-title p {
                font-size: 10px;
                margin: 0;
                color: #555;
            }
            .data-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 10px;
            }
            .data-table th {
                border: 1px solid #444;
                background-color: #f2f2f2;
                padding: 6px 4px;
                font-weight: bold;
                text-align: center;
            }
            .data-table td {
                border: 1px solid #555;
                padding: 5px 4px;
            }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .font-bold { font-weight: bold; }
            .bg-totals {
                background-color: #f9f9f9;
                font-weight: bold;
            }
            .signature-table {
                width: 100%;
                margin-top: 30px;
                border-collapse: collapse;
            }
            .signature-table td {
                border: none;
                width: 50%;
            }
            .signature-box {
                text-align: center;
                font-size: 10px;
            }
            .signature-space {
                height: 50px;
            }
        </style>
    </head>
    <body>
        <!-- Kop Surat Table -->
        <table class="kop-table">
            <tr>
                <td class="kop-details">
                    <h1><?php echo htmlspecialchars($nama_sekolah); ?></h1>
                    <p>
                        <?php if (!empty($alamat_sekolah)) echo htmlspecialchars($alamat_sekolah); ?>
                        <?php if (!empty($telp_sekolah)) echo " | Telp: " . htmlspecialchars($telp_sekolah); ?>
                        <?php if (!empty($email_sekolah)) echo " | Email: " . htmlspecialchars($email_sekolah); ?>
                        <?php if (!empty($website_sekolah)) echo " | Web: " . htmlspecialchars($website_sekolah); ?>
                    </p>
                </td>
            </tr>
        </table>

        <!-- Title -->
        <div class="report-title">
            <h2>Laporan Rekapitulasi Keuangan Bulanan</h2>
            <p>Tahun Buku/Keuangan: <strong><?php echo $filter_tahun; ?></strong></p>
        </div>

        <!-- Table Data -->
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 5%;">No</th>
                    <th>Bulan</th>
                    <th>Total Pemasukan</th>
                    <th>Total Pengeluaran</th>
                    <th>Sisa Kas</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $m => $row): ?>
                    <tr>
                        <td class="text-center"><?php echo $m; ?></td>
                        <td class="font-bold"><?php echo $row['bulan']; ?></td>
                        <td class="text-right font-bold"><?php echo formatRupiah($row['total_in']); ?></td>
                        <td class="text-right"><?php echo formatRupiah($row['jurnal_out']); ?></td>
                        <td class="text-right font-bold"><?php echo formatRupiah($row['sisa_kas']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="bg-totals">
                    <td colspan="2" class="text-center">TOTAL TAHUNAN</td>
                    <td class="text-right font-bold"><?php echo formatRupiah($total_pemasukan_year); ?></td>
                    <td class="text-right"><?php echo formatRupiah($total_pengeluaran_year); ?></td>
                    <td class="text-right font-bold"><?php echo formatRupiah($total_sisa_kas_year); ?></td>
                </tr>
            </tfoot>
        </table>

        <!-- Signature -->
        <table class="signature-table">
            <tr>
                <td></td>
                <td>
                    <div class="signature-box">
                        <p>Jakarta, <?php echo tanggalIndo(date('Y-m-d')); ?></p>
                        <p><strong>Bendahara TPQ</strong></p>
                        <div class="signature-space"></div>
                        <p><u>( <?php echo htmlspecialchars($_SESSION['nama_petugas'] ?? '__________________________'); ?> )</u></p>
                    </div>
                </td>
            </tr>
        </table>
    </body>
    </html>
    <?php
    $html = ob_get_clean();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();
    $dompdf->stream("laporan_keuangan_bulanan_" . $filter_tahun . ".pdf", ["Attachment" => true]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Keuangan Bulanan <?php echo $filter_tahun; ?> - <?php echo htmlspecialchars($nama_sekolah); ?></title>
    <!-- Add Font Awesome for buttons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #333;
            line-height: 1.4;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        
        .container {
            max-width: 900px;
            margin: 20px auto;
            background-color: #fff;
            padding: 40px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border-radius: 4px;
        }

        /* Control Panel Styles (Hidden in Print) */
        .control-panel {
            background-color: #f1f3f5;
            border-bottom: 1px solid #dee2e6;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-primary { background-color: #4e73df; color: #fff; }
        .btn-primary:hover { background-color: #2e59d9; }
        .btn-secondary { background-color: #858796; color: #fff; }
        .btn-secondary:hover { background-color: #717384; }
        .btn-success { background-color: #1cc88a; color: #fff; }
        .btn-success:hover { background-color: #17a673; }
        .btn-danger { background-color: #e74a3b; color: #fff; }
        .btn-danger:hover { background-color: #be2617; }
        .btn i { margin-right: 8px; }

        /* Kop Surat (Letterhead) */
        .kop-surat {
            display: flex;
            align-items: center;
            border-bottom: 3px double #000;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .kop-logo {
            width: 80px;
            height: 80px;
            background-color: #eaeaea;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            color: #777;
            font-size: 32px;
            font-weight: bold;
        }
        .kop-info {
            flex-grow: 1;
            text-align: center;
        }
        .kop-info h1 {
            font-size: 20px;
            margin: 0 0 5px 0;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #1a1a1a;
        }
        .kop-info p {
            font-size: 12px;
            margin: 2px 0;
            color: #555;
        }

        /* Report Header */
        .report-header {
            text-align: center;
            margin-bottom: 25px;
        }
        .report-header h2 {
            font-size: 16px;
            margin: 0 0 5px 0;
            font-weight: 700;
            letter-spacing: 0.5px;
            color: #222;
        }
        .report-header p {
            font-size: 13px;
            margin: 0;
            color: #666;
        }

        /* Table Design */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 12px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px 8px;
        }
        th {
            background-color: #f8f9fc;
            font-weight: 600;
            color: #495057;
            text-align: center;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .font-bold { font-weight: bold; }
        .bg-totals {
            background-color: #f8f9fc;
            font-weight: bold;
        }

        /* Signature block */
        .signature-container {
            display: flex;
            justify-content: flex-end;
            margin-top: 40px;
            font-size: 13px;
        }
        .signature-box {
            text-align: center;
            width: 250px;
        }
        .signature-date {
            margin-bottom: 60px;
        }
        .signature-name {
            font-weight: bold;
            text-decoration: underline;
        }

        /* Print optimization */
        @media print {
            body {
                background-color: #fff;
            }
            .control-panel {
                display: none !important;
            }
            .container {
                box-shadow: none;
                padding: 0;
                margin: 0 auto;
                max-width: 100%;
            }
            @page {
                size: A4 portrait;
                margin: 15mm;
            }
        }
    </style>
</head>
<body>

    <!-- Control bar for preview mode -->
    <div class="control-panel no-print">
        <a href="index.php?tahun=<?php echo $filter_tahun; ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <div>
            <a href="export.php?tahun=<?php echo $filter_tahun; ?>&type=excel" class="btn btn-success" style="margin-right: 10px;">
                <i class="fas fa-file-excel"></i> Export Excel
            </a>
            <a href="export.php?tahun=<?php echo $filter_tahun; ?>&type=pdf" class="btn btn-danger" style="margin-right: 10px;">
                <i class="fas fa-file-pdf"></i> Download PDF (Dompdf)
            </a>
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Cetak / Simpan PDF
            </button>
        </div>
    </div>

    <div class="container">
        <!-- Professional Kop Surat -->
        <div class="kop-surat">
            <div class="kop-info">
                <h1><?php echo htmlspecialchars(strtoupper($nama_sekolah)); ?></h1>
                <?php if (!empty($alamat_sekolah)): ?>
                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($alamat_sekolah); ?></p>
                <?php endif; ?>
                <p>
                    <?php if (!empty($telp_sekolah)): ?>
                        <i class="fas fa-phone-alt"></i> <?php echo htmlspecialchars($telp_sekolah); ?>
                    <?php endif; ?>
                    <?php if (!empty($email_sekolah)): ?>
                        &nbsp;&nbsp;<i class="fas fa-envelope"></i> <?php echo htmlspecialchars($email_sekolah); ?>
                    <?php endif; ?>
                    <?php if (!empty($website_sekolah)): ?>
                        &nbsp;&nbsp;<i class="fas fa-globe"></i> <?php echo htmlspecialchars($website_sekolah); ?>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <!-- Report Header -->
        <div class="report-header">
            <h2>LAPORAN REKAPITULASI KEUANGAN BULANAN</h2>
            <p>Tahun Buku/Keuangan: <strong><?php echo $filter_tahun; ?></strong></p>
        </div>

        <!-- Report Table -->
        <table>
            <thead>
                <tr>
                    <th style="width: 5%;">No</th>
                    <th>Bulan</th>
                    <th>Total Pemasukan</th>
                    <th>Total Pengeluaran</th>
                    <th>Sisa Kas</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $m => $row): ?>
                    <tr>
                        <td class="text-center"><?php echo $m; ?></td>
                        <td class="font-bold"><?php echo $row['bulan']; ?></td>
                        <td class="text-right font-bold" style="color: #2e59d9;"><?php echo formatRupiah($row['total_in']); ?></td>
                        <td class="text-right" style="color: #e74a3b;"><?php echo formatRupiah($row['jurnal_out']); ?></td>
                        <td class="text-right font-bold" style="color: #1cc88a;"><?php echo formatRupiah($row['sisa_kas']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr class="bg-totals">
                    <td colspan="2" class="text-center">TOTAL TAHUNAN</td>
                    <td class="text-right font-bold" style="color: #2e59d9;"><?php echo formatRupiah($total_pemasukan_year); ?></td>
                    <td class="text-right" style="color: #e74a3b;"><?php echo formatRupiah($total_pengeluaran_year); ?></td>
                    <td class="text-right font-bold" style="color: #1cc88a;"><?php echo formatRupiah($total_sisa_kas_year); ?></td>
                </tr>
            </tfoot>
        </table>

        <!-- Signature Area -->
        <div class="signature-container">
            <div class="signature-box">
                <div class="signature-date">Jakarta, <?php echo tanggalIndo(date('Y-m-d')); ?></div>
                <div class="signature-title">Bendahara TPQ</div>
                <div style="height: 60px;"></div>
                <div class="signature-name"><?php echo htmlspecialchars($_SESSION['nama_petugas'] ?? '__________________________'); ?></div>
            </div>
        </div>
    </div>
</body>
</html>


