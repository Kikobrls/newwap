<?php
/**
 * Pembayaran Tagihan
 * Sistem Keuangan TPQ
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config/app.php';
require_once '../../config/database.php';

// Check login
if (!isset($_SESSION['login'])) {
    header("Location: ../../login.php");
    exit;
}

// Handle delete pembayaran
if (isset($_GET['delete'])) {
    $id = (int) sanitize($_GET['delete']);

    if (mysqli_query($conn, "DELETE FROM pembayaran WHERE id_pembayaran = '$id'")) {
        logActivity('Menghapus data pembayaran', 'pembayaran', $id);
        setFlash('success', 'Data pembayaran berhasil dihapus!');
    } else {
        setFlash('danger', 'Gagal menghapus data pembayaran!');
    }
    header('Location: index.php');
    exit;
}

$page_title = 'Pembayaran';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

$filter_bulan = isset($_GET['bulan']) ? sanitize($_GET['bulan']) : date('m');
$filter_tahun = isset($_GET['tahun']) ? sanitize($_GET['tahun']) : date('Y');
$filter_kelas = isset($_GET['kelas']) ? sanitize($_GET['kelas']) : '';
$filter_iuran = isset($_GET['iuran']) ? sanitize($_GET['iuran']) : '';

$where = "WHERE MONTH(p.tgl_bayar) = '$filter_bulan' AND YEAR(p.tgl_bayar) = '$filter_tahun'";
if (!empty($filter_kelas)) {
    $where .= " AND s.id_kelas = '$filter_kelas'";
}
if (!empty($filter_iuran)) {
    $where .= " AND p.id_iuran = '$filter_iuran'";
}

$query = "SELECT p.*, s.nama as nama_santri, k.nama_kelas, b.nama_iuran, b.tahun as tahun_iuran,
                 p.metode_bayar as metode_transaksi,
                 g.nama_petugas as nama_petugas
          FROM pembayaran p
          JOIN santri s ON p.id_santri = s.id_santri
          JOIN kelas k ON s.id_kelas = k.id_kelas
          JOIN iuran b ON p.id_iuran = b.id_iuran
          LEFT JOIN petugas g ON p.id_petugas = g.id_petugas
          $where
          ORDER BY p.tgl_bayar DESC, p.id_pembayaran DESC";
$result = mysqli_query($conn, $query);

$total = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COALESCE(SUM(p.jumlah_bayar), 0) as total, COUNT(*) as jumlah
    FROM pembayaran p
    JOIN santri s ON p.id_santri = s.id_santri
    $where
"));

$kelas_list = mysqli_query($conn, 'SELECT * FROM kelas ORDER BY nama_kelas');
$iuran_list = mysqli_query($conn, 'SELECT * FROM iuran ORDER BY nama_iuran ASC, tahun DESC');

$bulan_list = [
    '01' => 'Januari',
    '02' => 'Februari',
    '03' => 'Maret',
    '04' => 'April',
    '05' => 'Mei',
    '06' => 'Juni',
    '07' => 'Juli',
    '08' => 'Agustus',
    '09' => 'September',
    '10' => 'Oktober',
    '11' => 'November',
    '12' => 'Desember'
];
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-money-bill-wave"></i></div>
                        Pembayaran Tagihan
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <button class="btn btn-secondary" type="button" data-bs-toggle="collapse"
                        data-bs-target="#collapseFilter" aria-expanded="false" aria-controls="collapseFilter">
                        <i class="fas fa-filter me-1"></i> Filter
                    </button>
                    <a href="add.php" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Input Pembayaran
                    </a>
                    <a href="bulk.php" class="btn btn-success">
                        <i class="fas fa-layer-group me-1"></i> Pembayaran Kolektif
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <div class="collapse mb-4 <?php echo (!empty($_GET['bulan']) || !empty($_GET['tahun']) || !empty($_GET['kelas']) || !empty($_GET['iuran'])) ? 'show' : ''; ?>"
        id="collapseFilter">
        <div class="card shadow">
            <div class="card-body">
                <form method="GET" class="form-inline">
                    <div class="form-group mr-3">
                        <label class="mr-2">Bulan:</label>
                        <select name="bulan" class="form-control">
                            <?php foreach ($bulan_list as $key => $bulan): ?>
                                <option value="<?php echo $key; ?>" <?php echo $filter_bulan == $key ? 'selected' : ''; ?>>
                                    <?php echo $bulan; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mr-3">
                        <label class="mr-2">Tahun:</label>
                        <select name="tahun" class="form-control">
                            <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                                <option value="<?php echo $y; ?>" <?php echo $filter_tahun == $y ? 'selected' : ''; ?>>
                                    <?php echo $y; ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group mr-3">
                        <label class="mr-2">Kelas:</label>
                        <select name="kelas" class="form-control">
                            <option value="">Semua Kelas</option>
                            <?php while ($kelas = mysqli_fetch_assoc($kelas_list)): ?>
                                <option value="<?php echo $kelas['id_kelas']; ?>" <?php echo $filter_kelas == $kelas['id_kelas'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($kelas['nama_kelas']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group mr-3">
                        <label class="mr-2">Tagihan:</label>
                        <select name="iuran" class="form-control">
                            <option value="">Semua Tagihan</option>
                            <?php while ($iuran = mysqli_fetch_assoc($iuran_list)): ?>
                                <option value="<?php echo $iuran['id_iuran']; ?>" <?php echo $filter_iuran == $iuran['id_iuran'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($iuran['nama_iuran'] . ' (' . $iuran['tahun'] . ')'); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Total Pembayaran (<?php echo $bulan_list[$filter_bulan] . ' ' . $filter_tahun; ?>)
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo formatRupiah($total['total']); ?>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-money-bill-wave fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Jumlah Detail Pembayaran
                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                <?php echo number_format($total['jumlah']); ?> Item
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-receipt fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Riwayat Pembayaran</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Santri</th>
                            <th>Kelas</th>
                            <th>Periode</th>
                            <th>Tagihan/Iuran</th>
                            <th>Jumlah</th>
                            <th>Petugas</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo date('d/m/Y', strtotime($row['tgl_bayar'])); ?></td>
                                <td><span
                                        class="font-weight-bold"><?php echo htmlspecialchars($row['nama_santri']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>
                                <td><?php echo htmlspecialchars(formatPeriodeTagihan($row['periode_tipe'] ?: 'bulanan', $row['bulan_dibayar'], $row['tahun_dibayar'])); ?>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['nama_iuran']); ?></strong><br>
                                    <small class="text-muted">Periode Iuran <?php echo $row['tahun_iuran']; ?></small>
                                </td>
                                <td class="font-weight-bold text-success"><?php echo formatRupiah($row['jumlah_bayar']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['nama_petugas'] ?: '-'); ?></td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark"
                                            onclick="confirmDelete('index.php?delete=<?php echo $row['id_pembayaran']; ?>')"
                                            title="Hapus Pembayaran">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>
