<?php
/**
 * Halaman Data Pos Keuangan
 * Sistem Keuangan TPQ
 *
 * Satu file menangani 4 aksi:
 *   1. HAPUS  : GET  ?delete=<id_pos>, ditolak jika pos masih
 *               dipakai di jurnal_umum              -> redirect index.php
 *   2. TAMBAH : POST action=add                     -> redirect index.php
 *   3. EDIT   : POST action=edit (wajib id_pos)     -> redirect index.php
 *   4. TAMPIL : GET biasa, daftar pos keuangan
 *
 * Aksi 1-3 dijalankan SEBELUM output HTML agar header() redirect valid.
 */

// Start session dan config terlebih dahulu
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once '../../config/app.php';
require_once '../../config/database.php';

/* =========================================================
 * AKSI 1: HAPUS DATA (GET ?delete=<id_pos>)
 * ========================================================= */
if (isset($_GET['delete'])) {
    $id = sanitize($_GET['delete']);

    // Check if Pos Keuangan is used in jurnal_umum
    $check = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM jurnal_umum WHERE id_pos = '$id'"));

    if ($check['total'] > 0) {
        setFlash('danger', 'Pos Keuangan tidak dapat dihapus karena digunakan pada jurnal umum!');
    }
    else {
        if (mysqli_query($conn, "DELETE FROM pos_keuangan WHERE id_pos = '$id'")) {
            logActivity('Menghapus data Pos Keuangan', 'pos_keuangan', $id);
            setFlash('success', 'Data Pos Keuangan berhasil dihapus!');
        }
        else {
            setFlash('danger', 'Gagal menghapus data Pos Keuangan!');
        }
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 2: TAMBAH DATA (POST action=add)
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'add') {
    $nama_pos = sanitize($_POST['nama_pos']);

    // Validasi: nama pos wajib diisi
    if (empty($nama_pos)) {
        setFlash('danger', 'Nama Pos Keuangan harus diisi!');
    } elseif (mysqli_query($conn, "INSERT INTO pos_keuangan (nama_pos) VALUES ('$nama_pos')")) {
        logActivity('Menambah data Pos Keuangan', 'pos_keuangan', mysqli_insert_id($conn));
        setFlash('success', 'Data Pos Keuangan berhasil ditambahkan!');
    } else {
        setFlash('danger', 'Gagal menambah data Pos Keuangan!');
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 3: EDIT DATA (POST action=edit)
 * ========================================================= */
if ($_SERVER['REQUEST_METHOD'] == 'POST' && ($_POST['action'] ?? '') == 'edit') {
    $id_pos   = sanitize($_POST['id_pos'] ?? '');
    $nama_pos = sanitize($_POST['nama_pos']);

    // Validasi: id_pos (terisi otomatis dari tombol Edit) dan nama pos wajib ada
    if (empty($id_pos) || empty($nama_pos)) {
        setFlash('danger', 'Nama Pos Keuangan harus diisi!');
    } elseif (mysqli_query($conn, "UPDATE pos_keuangan SET nama_pos = '$nama_pos' WHERE id_pos = '$id_pos'")) {
        logActivity('Mengubah data Pos Keuangan', 'pos_keuangan', $id_pos);
        setFlash('success', 'Data Pos Keuangan berhasil diubah!');
    } else {
        setFlash('danger', 'Gagal mengubah data Pos Keuangan!');
    }
    header("Location: index.php");
    exit;
}

/* =========================================================
 * AKSI 4: TAMPILKAN HALAMAN (daftar pos keuangan)
 * ========================================================= */

// Include layout SETELAH logika redirect di atas
$page_title = 'Data Pos Keuangan';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

// Ambil seluruh data pos keuangan
$query = "SELECT * FROM pos_keuangan ORDER BY nama_pos ASC";
$result = mysqli_query($conn, $query);
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-tags"></i></div>
                        Data Pos Keuangan
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#posModal"
                        onclick="resetForm()">
                        <i class="fas fa-plus me-1"></i> Tambah Pos
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pos Keuangan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="5%">No</th>
                            <th>Nama Pos Keuangan</th>
                            <th width="15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td class="font-weight-bold text-primary"><?php echo htmlspecialchars($row['nama_pos']); ?></td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                            <button class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle" id="dropdownMenuLink_<?php echo $row['id_pos']; ?>" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink_<?php echo $row['id_pos']; ?>">
                                                <div class="dropdown-header">Aksi:</div>
                                                <a class="dropdown-item" href="javascript:void(0)" onclick='editPos(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES, "UTF-8"); ?>)'>
                                                    <i class="fas fa-edit fa-sm fa-fw mr-2 text-gray-400"></i> Edit
                                                </a>
                                            </div>
                                        </div>
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark" onclick="confirmDelete('index.php?delete=<?php echo $row['id_pos']; ?>')">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php
endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-xl -->

<!-- Modal -->
<div class="modal fade" id="posModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Tambah Pos Keuangan</h5>
                <button class="close" type="button" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="action" id="form_action" value="add">
                    <input type="hidden" name="id_pos" id="id_pos">
                    <div class="form-group">
                        <label>Nama Pos Keuangan <span class="text-danger">*</span></label>
                        <input type="text" name="nama_pos" id="nama_pos" class="form-control" placeholder="Contoh: ATK, Gaji, dll" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
$extra_js = '
<script>
function resetForm() {
    document.getElementById("modalTitle").textContent = "Tambah Pos Keuangan";
    document.getElementById("form_action").value = "add";
    document.getElementById("id_pos").value = "";
    document.getElementById("nama_pos").value = "";
}

function editPos(data) {
    document.getElementById("modalTitle").textContent = "Edit Pos Keuangan";
    document.getElementById("form_action").value = "edit";
    document.getElementById("id_pos").value = data.id_pos;
    document.getElementById("nama_pos").value = data.nama_pos;
    $("#posModal").modal("show");
}
</script>
';

require_once '../../includes/footer.php';
?>
