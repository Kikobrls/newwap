<?php
/**
 * Tambah Santri
 * Sistem Keuangan TPQ
 */

// Start output buffering to prevent header errors
ob_start();

$page_title = 'Tambah Santri';
require_once '../../includes/header.php';

$errors = [];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = sanitize($_POST['nama']);
    $tempat_lahir = sanitize($_POST['tempat_lahir']);
    $tanggal_lahir = sanitize($_POST['tanggal_lahir']);
    $id_kelas = sanitize($_POST['id_kelas']);
    $alamat = sanitize($_POST['alamat']);
    $id_iuran_list = $_POST['id_iuran'] ?? [];
    $id_iuran_clean = [];
    if (is_array($id_iuran_list)) {
        foreach ($id_iuran_list as $id_iuran_item) {
            $id_iuran_item = (int)sanitize($id_iuran_item);
            if ($id_iuran_item > 0) {
                $id_iuran_clean[] = $id_iuran_item;
            }
        }
    }

    // Validation
    if (empty($nama)) $errors[] = "Nama harus diisi!";
    if (empty($id_kelas)) $errors[] = "Kelas harus dipilih!";
    if (empty($id_iuran_clean))
        $errors[] = "Kategori Iuran harus dipilih!";

    if (empty($errors)) {
        $id_iuran_utama = (int)$id_iuran_clean[0];
        $query = "INSERT INTO santri (nama, tempat_lahir, tanggal_lahir, id_kelas, alamat, id_iuran)
                  VALUES ('$nama', '$tempat_lahir', '$tanggal_lahir', '$id_kelas', '$alamat', '$id_iuran_utama')";

        if (mysqli_query($conn, $query)) {
            $new_id = mysqli_insert_id($conn);

            foreach ($id_iuran_clean as $id_iuran_item) {
                mysqli_query($conn, "
                    INSERT INTO santri_iuran (id_santri, id_iuran, is_active)
                    VALUES ('$new_id', '$id_iuran_item', 1)
                    ON DUPLICATE KEY UPDATE is_active = 1
                ");
            }

            logActivity('Menambah data santri baru', 'santri', $new_id);
            setFlash('success', 'Data santri berhasil ditambahkan!');

            // Clean output buffer and redirect
            ob_end_clean();
            header("Location: index.php");
            exit;
        } else {
            $errors[] = "Gagal menyimpan data: " . mysqli_error($conn);
        }
    }
}

// Get kelas
$kelas_list = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas");

// Get Iuran grouped by period type
$iuran_result = mysqli_query($conn, "SELECT * FROM iuran ORDER BY periode_tipe ASC, nama_iuran ASC, tahun DESC");
$iuran_grouped = [
    'bulanan' => [],
    'tahunan' => [],
    'lainnya' => []
];
while ($iuran_result && ($iuran = mysqli_fetch_assoc($iuran_result))) {
    $type = $iuran['periode_tipe'] ?? 'lainnya';
    if (!isset($iuran_grouped[$type])) {
        $type = 'lainnya';
    }
    $iuran_grouped[$type][] = $iuran;
}

require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-user-plus"></i></div>
                        Tambah Santri
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <a href="index.php" class="btn btn-sm btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <?php if (!empty($errors)): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Terjadi Kesalahan!',
                html: '<?php echo addslashes(implode('<br>', $errors)); ?>',
                showConfirmButton: true
            });
        </script>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Form Tambah Santri</h6>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" name="nama" class="form-control"
                                value="<?php echo isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : ''; ?>" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tempat Lahir</label>
                                    <input type="text" name="tempat_lahir" class="form-control"
                                        value="<?php echo isset($_POST['tempat_lahir']) ? htmlspecialchars($_POST['tempat_lahir']) : ''; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tanggal Lahir</label>
                                    <input type="date" name="tanggal_lahir" class="form-control"
                                        value="<?php echo isset($_POST['tanggal_lahir']) ? htmlspecialchars($_POST['tanggal_lahir']) : ''; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Kelas <span class="text-danger">*</span></label>
                            <select name="id_kelas" class="form-control" required>
                                <option value="">-- Pilih Kelas --</option>
                                <?php while ($kelas = mysqli_fetch_assoc($kelas_list)): ?>
                                    <option value="<?php echo $kelas['id_kelas']; ?>" <?php echo (isset($_POST['id_kelas']) && $_POST['id_kelas'] == $kelas['id_kelas']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($kelas['nama_kelas']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Kategori Iuran (Tagihan) <span class="text-danger">*</span></label>
                            <div class="border rounded p-3" style="max-height: 280px; overflow-y: auto;">
                                <?php foreach (['bulanan' => 'Tagihan Bulanan', 'tahunan' => 'Tagihan Tahunan', 'lainnya' => 'Lainnya'] as $key => $label): ?>
                                    <?php if (!empty($iuran_grouped[$key])): ?>
                                        <div class="font-weight-bold text-primary mb-2"><?php echo $label; ?></div>
                                        <?php foreach ($iuran_grouped[$key] as $iuran): ?>
                                            <div class="custom-control custom-checkbox mb-2 ml-1">
                                                <input
                                                    type="checkbox"
                                                    class="custom-control-input"
                                                    id="iuran_<?php echo (int)$iuran['id_iuran']; ?>"
                                                    name="id_iuran[]"
                                                    value="<?php echo (int)$iuran['id_iuran']; ?>"
                                                    <?php echo (isset($_POST['id_iuran']) && is_array($_POST['id_iuran']) && in_array($iuran['id_iuran'], $_POST['id_iuran'])) ? 'checked' : ''; ?>>
                                                <label class="custom-control-label" for="iuran_<?php echo (int)$iuran['id_iuran']; ?>">
                                                    <?php echo htmlspecialchars($iuran['nama_iuran']); ?> (<?php echo $iuran['tahun']; ?>) - <?php echo formatRupiah($iuran['nominal']); ?>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                        <hr class="my-2">
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <small class="text-muted">Centang satu atau lebih kategori iuran.</small>
                        </div>
                        <div class="form-group">
                            <label>Alamat</label>
                            <textarea name="alamat" class="form-control"
                                rows="3"><?php echo isset($_POST['alamat']) ? htmlspecialchars($_POST['alamat']) : ''; ?></textarea>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="text-right">
                    <button type="submit" class="btn btn-primary px-4">
                        <i class="fas fa-save mr-2"></i>Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php require_once '../../includes/footer.php'; ?>
