<?php
/**
 * Data Santri
 * Sistem Keuangan TPQ
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../../config/app.php';
require_once '../../config/database.php';

// Handle delete - BEFORE any HTML output
if (isset($_GET['delete'])) {
    $id = (int) sanitize($_GET['delete']);

    // Riwayat pembayaran & tagihan santri terhapus otomatis oleh database
    // (FK ON DELETE CASCADE — lihat migrations/2026_08_05_cascade_delete_santri.sql)
    $jml_bayar = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM pembayaran WHERE id_santri = '$id'"))['total'];

    if (mysqli_query($conn, "DELETE FROM santri WHERE id_santri = '$id'")) {
        logActivity("Menghapus data santri beserta $jml_bayar riwayat pembayaran", 'santri', $id);
        setFlash('success', $jml_bayar > 0
            ? "Data santri berhasil dihapus beserta $jml_bayar riwayat pembayarannya!"
            : 'Data santri berhasil dihapus!');
    } else {
        setFlash('danger', 'Gagal menghapus data santri! ' . mysqli_error($conn));
    }
    header("Location: index.php");
    exit;
}

$page_title = 'Data Santri';
require_once '../../includes/header.php';
require_once '../../includes/sidebar.php';
require_once '../../includes/topbar.php';

// Get data
$query = "SELECT s.*, k.nama_kelas, b.nominal, b.tahun as tahun_iuran, b.nama_iuran,
                 (SELECT COUNT(*) FROM pembayaran p WHERE p.id_santri = s.id_santri) AS jml_pembayaran
          FROM santri s
          JOIN kelas k ON s.id_kelas = k.id_kelas
          JOIN iuran b ON s.id_iuran = b.id_iuran
          ORDER BY k.nama_kelas, s.nama";
$result = mysqli_query($conn, $query);

$santri_rows = [];
while ($result && ($row = mysqli_fetch_assoc($result))) {
    $santri_rows[] = $row;
}
$santri_ids = array_column($santri_rows, 'id_santri');
$monthly_progress_map = getSantriMonthlyProgressMap($santri_ids);
$yearly_progress_map = getSantriYearlyProgressMap($santri_ids);

// Get kelas for filter
$kelas_list = mysqli_query($conn, "SELECT * FROM kelas ORDER BY nama_kelas");
?>

<!-- Page Header (SB Admin Pro style) -->
<header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
    <div class="container-xl px-4">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-user-graduate"></i></div>
                        Data Santri
                    </h1>
                </div>
                <div class="col-12 col-md-auto mb-3">
                    <a href="<?php echo $base_url; ?>/pages/santri/pindahkelas.php" class="btn btn-outline-primary me-2">
                        <i class="fas fa-exchange-alt me-1"></i> Pindah Kelas
                    </a>
                    <a href="add.php" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Tambah Santri
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<!-- Begin Page Content -->
<div class="container-xl px-4 mt-4">

    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Santri</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Santri</th>
                            <th>Umur</th>
                            <th>Kelas</th>
                            <th>Status Bulanan</th>
                            <th>Status Tahunan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1;
                        foreach ($santri_rows as $row):
                            $monthly_progress = $monthly_progress_map[(int) $row['id_santri']] ?? null;
                            $yearly_progress = $yearly_progress_map[(int) $row['id_santri']] ?? null;
                            $konfirmasi_hapus = $row['jml_pembayaran'] > 0
                                ? "Hapus santri \"{$row['nama']}\"?\n\n{$row['jml_pembayaran']} riwayat pembayarannya JUGA akan terhapus dan Sisa Kas akan berkurang. Aksi ini tidak dapat dibatalkan."
                                : "Hapus santri \"{$row['nama']}\"? Aksi ini tidak dapat dibatalkan."; ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td class="font-weight-bold text-primary"><?php echo htmlspecialchars($row['nama']); ?></td>
                                <td>
                                    <?php
                                    if (!empty($row['tanggal_lahir'])) {
                                        $bday = new DateTime($row['tanggal_lahir']);
                                        $today = new DateTime();
                                        echo $today->diff($bday)->y . ' Tahun';
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['nama_kelas']); ?></td>

                                <td>
                                    <?php if ($monthly_progress): ?>
                                        <?php
                                        $monthly_text = $monthly_progress['status_text'];
                                        if (stripos($monthly_text, 'Belum ada pembayaran') !== false) {
                                            $monthly_text = 'Belum lunas';
                                        }
                                        $bg_class = $monthly_progress['badge'];
                                        $text_class = in_array($bg_class, ['warning', 'info', 'light']) ? 'text-dark' : 'text-white';
                                        ?>
                                        <span class="badge bg-<?php echo $bg_class; ?> <?php echo $text_class; ?> badge-status">
                                            <?php echo htmlspecialchars($monthly_text); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary text-white badge-status">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($yearly_progress): ?>
                                        <?php
                                        $yearly_text = $yearly_progress['status_text'];
                                        if (stripos($yearly_text, 'Belum ada pembayaran') !== false) {
                                            $yearly_text = 'Belum lunas';
                                        }
                                        $bg_class_y = $yearly_progress['badge'];
                                        $text_class_y = in_array($bg_class_y, ['warning', 'info', 'light']) ? 'text-dark' : 'text-white';
                                        ?>
                                        <span
                                            class="badge bg-<?php echo $bg_class_y; ?> <?php echo $text_class_y; ?> badge-status">
                                            <?php echo htmlspecialchars($yearly_text); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary text-white badge-status">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <span
                                        class="badge bg-<?php echo $row['status'] == 'active' ? 'success' : 'secondary'; ?> text-white">
                                        <?php echo $row['status'] == 'active' ? 'Aktif' : 'Nonaktif'; ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <div class="dropdown no-caret me-2">
                                            <button class="btn btn-datatable btn-icon btn-transparent-dark dropdown-toggle"
                                                id="dropdownMenuLink_<?php echo $row['id_santri']; ?>"
                                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                                                aria-labelledby="dropdownMenuLink_<?php echo $row['id_santri']; ?>">
                                                <div class="dropdown-header">Aksi:</div>
                                                <a class="dropdown-item"
                                                    href="view.php?id=<?php echo $row['id_santri']; ?>">
                                                    <i class="fas fa-eye fa-sm fa-fw mr-2 text-gray-400"></i> Detail
                                                </a>
                                                <a class="dropdown-item"
                                                    href="edit.php?id=<?php echo $row['id_santri']; ?>">
                                                    <i class="fas fa-edit fa-sm fa-fw mr-2 text-gray-400"></i> Edit
                                                </a>
                                            </div>
                                        </div>
                                        <button class="btn btn-datatable btn-icon btn-transparent-dark"
                                            onclick="confirmDelete('index.php?delete=<?php echo $row['id_santri']; ?>', this.dataset.pesan)"
                                            data-pesan="<?php echo htmlspecialchars($konfirmasi_hapus, ENT_QUOTES); ?>">
                                            <i class="far fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-xl -->

<?php require_once '../../includes/footer.php'; ?>
